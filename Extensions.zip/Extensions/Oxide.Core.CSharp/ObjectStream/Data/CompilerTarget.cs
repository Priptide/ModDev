using System;

namespace ObjectStream.Data
{
    [Serializable]
    internal enum CompilerTarget
    {
        Library, Exe, Module, WinExe
    }
}
