﻿using System;
using System.Reflection;
using Oxide.Core;
using Oxide.Core.Plugins;

namespace Oxide.Plugins
{
    [Info("CodeLockChanger", "Priptide", 0.1)]
    [Description("Send Help Plz")]

    class Test : CSharpPlugin
    { 
        void Init()
        {
            //Similar To Start

            Puts("Init works Yeet!");

        }

        void Loaded()
        {
            //Similar To Start But When Unpacking Finished

            Puts("Loaded works Yeet!");
        }

        void OnFrame()
        {
            //Similar To Update
        }

        void OnTick()
        {
            //Similar To Update
        }
    }
}
